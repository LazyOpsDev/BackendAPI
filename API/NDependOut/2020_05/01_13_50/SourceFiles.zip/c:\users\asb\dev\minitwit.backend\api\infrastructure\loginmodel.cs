﻿namespace Infrastructure
{
    public class LoginModel
    {
        //[BindProperty]
        public string Username { get; set; }
        //[BindProperty]
        public string Password { get; set; }
    }
}
