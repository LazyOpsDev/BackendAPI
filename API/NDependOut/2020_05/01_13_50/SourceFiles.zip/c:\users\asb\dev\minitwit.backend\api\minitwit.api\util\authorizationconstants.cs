﻿namespace Minitwit.API.Util
{
    public class AuthorizationConstants
    {
        public static readonly string terribleHackAuth = "Basic c2ltdWxhdG9yOnN1cGVyX3NhZmUh";
    }
}
